package com.example.agrotara

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
