import 'package:agrotara/mainpage.dart';
import 'package:get/get.dart';
import 'package:agrotara/agrodrive.dart';


class AppRoutes {
  static const MAIN = '/main';
  static const AGRODRIVE = '/agrodrive';
  static const AGROINSIGHT = '/agroinsight';

  static final routes = [
    GetPage(name: MAIN, page: () => MainPage()),
    GetPage(name: AGRODRIVE, page: () => AgroDrivePage()),
    GetPage(name: AGROINSIGHT, page: () => AgroInsightPage()),
  ];
}
